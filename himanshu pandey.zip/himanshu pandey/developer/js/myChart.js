  window.onload = function () {
    var chart = new CanvasJS.Chart("chartContainer", {

      title:{
        text: "First Quarter Run"              
      },
      data: [//array of dataSeries              
        { //dataSeries object

         /*** Change type "column" to "bar", "area", "line" or "pie"***/
         type: "column",
         dataPoints: [
         { label: "Aman", y: 18 },
         { label: "Raju", y: 29 },
         { label: "George", y: 40 },                                    
         { label: "Grunt", y: 34 },
         { label: "Javed", y: 24 }
         ]
       }
       ]
     });

    chart.render();
  }